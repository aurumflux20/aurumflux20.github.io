Verification pack for pulse

  python ledger.py .

Prints VERIFIED if the chain is intact, every forecast predates its deadline and all
signatures match pubkey.txt. Bitcoin anchors: pip install opentimestamps-client, then
  ots verify anchors/<file>.ots -d <hash>
